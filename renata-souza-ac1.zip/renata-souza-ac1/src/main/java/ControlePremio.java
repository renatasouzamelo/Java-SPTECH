import java.util.ArrayList;
import java.util.List;

public class ControlePremio {
    //Atributo
    private List<Ipremio> ipremios;

    //Construtor


    public ControlePremio(List<Ipremio> ipremios) {
        this.ipremios = ipremios;
    }

    public ControlePremio() {

    }

    //Método calcular  total de prêmio pago
    public Double calcularTotalPremio() {
        System.out.println("Exibir valor total de premios");
        Double valorTotalPremios = 0.00;
        for (Ipremio p : ipremios) {
            valorTotalPremios += p.getValorPremio();
        }
        return valorTotalPremios;
    }


}
