public interface Ipremio {
    public Double getValorPremio();
}
