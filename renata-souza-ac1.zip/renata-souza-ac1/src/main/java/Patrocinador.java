public abstract class Patrocinador implements Ipremio {
    private String nome;
    private String nomeEquipe;
    private int vitorias;
    private Double valorInvestido;

    private Double premio;

    public Patrocinador(String nome, String nomeEquipe, int vitorias, Double valorInvestido, Double premio) {
        this.nome = nome;
        this.nomeEquipe = nomeEquipe;
        this.vitorias = vitorias;
        this.valorInvestido = valorInvestido;
        this.premio = premio;
    }

    public String getNome() {
        return nome;
    }

    public String getNomeEquipe() {
        return nomeEquipe;
    }

    public int getVitorias() {
        return vitorias;
    }

    public Double getValorInvestido() {
        return valorInvestido;
    }

    @Override
    public Double getValorPremio() {
        return getVitorias() * 0.2;
    }



    @Override
    public String toString() {
        return " Nome{" +
                nomeEquipe +
                "Vitoria" +
                vitorias +
                "Valor investido" +
                valorInvestido +
                "Premio" +
                getValorPremio()+
                "}" + super.toString();
    }
}
