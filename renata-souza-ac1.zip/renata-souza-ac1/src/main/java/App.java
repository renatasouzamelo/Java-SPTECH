public class App {
    public static void main(String[] args) {
        //Criação de objetos Vendaveis
        //JogadorAtacante j1 = new JogadorAtacante("Pedro", "Palmeiras",
          //      2, 10.000, 2, 1, "Cassio");
        //JogadorGoleiro j2 = new JogadorGoleiro("Rafael", "Core", 1,
             //   2000.000, 2, 2);

    }
}
