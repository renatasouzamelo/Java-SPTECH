public class JogadorAtacante extends Patrocinador{

    private int codigo;
    private String nome;
    private int nroJogos;
    private int golsMarcados;
    private int assistencias;

    private int desempenho;

    public JogadorAtacante(String nome, String nomeEquipe, int vitorias, Double valorInvestido, Double premio, int codigo,
                           String nome1, int nroJogos, int golsMarcados, int assistencias, int desempenho) {
        super(nome, nomeEquipe, vitorias, valorInvestido, premio);
        this.codigo = codigo;
        this.nome = nome1;
        this.nroJogos = nroJogos;
        this.golsMarcados = golsMarcados;
        this.assistencias = assistencias;
        this.desempenho = desempenho;
    }

    public int getCodigo() {
        return codigo;
    }

    @Override
    public String getNome() {
        return nome;
    }

    public int getNroJogos() {
        return nroJogos;
    }

    public int getGolsMarcados() {
        return golsMarcados;
    }

    public int getAssistencias() {
        return assistencias;
    }

    public int getDesempenho() {
        return (golsMarcados+ assistencias)/ getGolsMarcados();
    }

    @Override
    public Double getValorPremio() {
        return getDesempenho() * 0.200;
    }

    @Override
    public String toString() {
        return " Codigo{" +
            codigo +
                    "Nome" +
                    nome +
                    "Numero de jogos" +
                    nroJogos +
                    "Gols"+
                    golsMarcados+
                     "Assistencia"+
                      assistencias+
                    "Desempenho"+
                   getDesempenho()+
                    "Valor premio"+
                getValorPremio()+
                "}" + super.toString();
    }


}
