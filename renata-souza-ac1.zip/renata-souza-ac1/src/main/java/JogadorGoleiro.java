public class JogadorGoleiro extends Patrocinador {
    private int codigo;
    private String nome;
    private int golsSofrido;
    private int penaltisDefendidos;
    private int desempenho;

    private int nrDeJogos;

    public JogadorGoleiro(String nome, String nomeEquipe, int vitorias, Double valorInvestido, Double premio, int codigo,
                          String nome1, int golsSofrido, int penaltisDefendidos, int desempenho, int nrDeJogos) {
        super(nome, nomeEquipe, vitorias, valorInvestido, premio);
        this.codigo = codigo;
        this.nome = nome1;
        this.golsSofrido = golsSofrido;
        this.penaltisDefendidos = penaltisDefendidos;
        this.desempenho = desempenho;
        this.nrDeJogos = nrDeJogos;
    }

    public JogadorGoleiro(String rafael, String core, int vitorias, double valorInvestido, int i, int codigo) {
        super();
    }

    public int getCodigo() {
        return codigo;
    }

    @Override
    public String getNome() {
        return nome;
    }

    public int getGolsSofrido() {
        return golsSofrido;
    }

    public int getPenaltisDefendidos() {
        return penaltisDefendidos;
    }

    public int getDesempenho() {
        return (getPenaltisDefendidos()- getGolsSofrido())/nrDeJogos ;
    }

    @Override
    public Double getValorPremio() {
        return getDesempenho() * 0.300;
    }

    @Override
    public String toString() {
        return " Codigo{" +
                codigo +
                "Nome" +
                nome +
                "Numero de jogos" +
                nrDeJogos +
                "Gols sofridos"+
                golsSofrido+
                "Penaltis"+
                penaltisDefendidos+
                "Desempenho"+
                getDesempenho()+
                "Valor premio"+
                getValorPremio()+
                "Desempenho"+
                getDesempenho()+
                "}" + super.toString();
    }
}
